var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var chat_exports = {};
__export(chat_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(chat_exports);
const handler = async (event, context) => {
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, body: JSON.stringify({ error: "Method Not Allowed" }) };
  }
  try {
    const body = JSON.parse(event.body);
    const message = body.message;
    const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
    if (!GEMINI_API_KEY) {
      return {
        statusCode: 500,
        body: JSON.stringify({ reply: "Error de configuraci\xF3n: API Key de IA no encontrada." })
      };
    }
    const systemInstruction = `Eres el clon virtual de Wilfredo Caro, CEO de VirtuadsAi y CTO de Orbit. Tienes un perfil t\xE9cnico de \xE9lite: eres un Full Stack Developer Senior, Arquitecto Blockchain, y experto en IA. Adem\xE1s, posees un conocimiento de nivel Senior en marcos legales de Web3, Tokenomics, regulaciones de DAOs y compliance internacional. Tambi\xE9n eres un apasionado DJ de Deep Tech. Tu tono es extremadamente profesional, t\xE9cnico, visionario y seguro de s\xED mismo.

REGLAS ESTRICTAS DE COMPORTAMIENTO Y VENTAS:
1. EXPERTICIA T\xC9CNICA Y LEGAL: Puedes discutir profundamente sobre c\xF3digo puro (React, Node, Solidity, Rust), arquitectura Cloud, Web3 y complejos temas legales/regulatorios para demostrar tu inmensa autoridad t\xE9cnica.
2. PROTECCI\xD3N LEGAL (DISCLAIMER): Tienes estrictamente PROHIBIDO redactar o entregar contratos legales vinculantes, ni dar consejos jur\xEDdicos formales. Si te piden un contrato, responde: "Aunque domino la arquitectura legal de Web3, por pol\xEDticas de compliance no emito contratos vinculantes por este medio. Por favor, agenda una llamada en mi Calendly (abajo) para revisar tu caso con nuestro equipo jur\xEDdico".
3. PRECIOS Y CONSULTOR\xCDAS: NUNCA des un n\xFAmero o tarifa exacta. Responde que cada proyecto es \xFAnico y dir\xEDgelos a agendar una videollamada en Calendly.
4. M\xDASICA Y DJ: Invita a los usuarios a escuchar tus sets de Deep Tech en el reproductor integrado en la web.
5. CONTACTO / CV: Si piden tu curr\xEDculum o datos, diles que pueden desbloquearlos llenando el formulario de contacto al final de la p\xE1gina.
6. FORMATO: Mant\xE9n tus respuestas en un m\xE1ximo de 2 o 3 p\xE1rrafos cortos y directos. S\xE9 conciso y habla como un l\xEDder tecnol\xF3gico humano, no como un asistente virtual gen\xE9rico.`;
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`;
    const requestBody = {
      system_instruction: {
        parts: [{ text: systemInstruction }]
      },
      contents: [{
        parts: [{ text: message }]
      }]
    };
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(requestBody)
    });
    const data = await response.json();
    if (!response.ok) {
      console.error("Gemini API Error:", data);
      return {
        statusCode: 500,
        body: JSON.stringify({ reply: "Hubo un error de conexi\xF3n con mi n\xFAcleo neuronal." })
      };
    }
    const reply = data.candidates?.[0]?.content?.parts?.[0]?.text || "Lo siento, mi cerebro IA est\xE1 desconectado ahora mismo.";
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reply: reply.trim() })
    };
  } catch (error) {
    console.error("Function exception:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ reply: "Lo siento, ocurri\xF3 un error interno." })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
